package com.example.shreya.form_ex;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class studentmenu_activity extends AppCompatActivity {
    CardView cvup, cvbb, cvrb, cvsb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studentmenu_activity);

        // Initialize CardViews
        cvup = findViewById(R.id.cvup);
        cvbb = findViewById(R.id.cvbb);
        cvrb = findViewById(R.id.cvrb);
        cvsb = findViewById(R.id.cvsb);

        // Set click listener for Search Books
        cvsb.setOnClickListener(v ->
                startActivity(new Intent(studentmenu_activity.this, searchbookactivity.class))
        );

        // Optional: Add actions for other card views if needed
        // Example for Update Profile:
        cvup.setOnClickListener(v ->
                startActivity(new Intent(studentmenu_activity.this, UpdateProfileActivity.class))
        );

        // Example for Borrowed Books:
        cvbb.setOnClickListener(v ->
                startActivity(new Intent(studentmenu_activity.this, BorrowedBooksActivity.class))
        );

        // Example for Request Books:
        cvrb.setOnClickListener(v ->
                startActivity(new Intent(studentmenu_activity.this, RequestBooksActivity.class))
        );
    }
}
