package com.example.shreya.form_ex;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class BorrowedBooksActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrowed_books);  // create this layout file too
    }
}
