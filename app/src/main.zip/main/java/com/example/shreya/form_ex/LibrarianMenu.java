package com.example.shreya.form_ex;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import android.view.View;

public class LibrarianMenu extends AppCompatActivity {

    CardView cardViewAddBooks,cardviewstudentlist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_librarian_menu);

        cardViewAddBooks = (CardView) findViewById(R.id.cardViewAddBooks);
        cardviewstudentlist = (CardView) findViewById(R.id.cardviewstudentlist);

        cardViewAddBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), addbookdetailsactivity.class));
            }
        });
        cardviewstudentlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Studentlistactivity.class));
            }
        });
    }
}
